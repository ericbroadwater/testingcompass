export const textJSONRtePaths = [
    // 'text.content'
]