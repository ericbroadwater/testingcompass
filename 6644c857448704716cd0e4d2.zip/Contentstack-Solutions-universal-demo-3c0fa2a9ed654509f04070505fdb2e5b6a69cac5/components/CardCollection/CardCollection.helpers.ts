export const imageCardsReferenceIncludes = [
    'cards.cta.link'
]