export const textAndImageReferenceIncludes = [
    'cta.link'
]