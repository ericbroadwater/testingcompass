export const includeheaderRefUids = [
    'items.link',
    'items.mega_menu',
    'items.mega_menu.sections.link',
    'items.mega_menu.sections.links.link',
    'items.mega_menu.cta_group',
    'items.mega_menu.cta_group.call_to_action.internal_link'
]