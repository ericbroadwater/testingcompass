
export const localStorageConfig ={
    webConfiguration: {
        key: process.env.LOCALSTORAGE_WEBCONFIG_KEY,
        ttl: process.env.LOCALSTORAGE_WEBCONFIG_TTL
    }
}